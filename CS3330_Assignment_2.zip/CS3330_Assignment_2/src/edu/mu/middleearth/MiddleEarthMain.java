package edu.mu.middleearth;

public class MiddleEarthMain {

    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.showMenu();
    }
}
